import UIKit

let str = """
4d
sdfdsfds

dsfdsfds
325

"""
let str2 = "dsfdsfdsf sdf dfs   dfsg dfg dfgdfg ddg "

extension String {
    func substringRange(in position: Int) -> ClosedRange<Int> {
        guard position < self.count, position >= 0, self.count > 0 else {
            fatalError("Position is out of string bounds")
        }
        if self[self.index(self.startIndex, offsetBy: position)] == "\n" {
            /**Нужное раскомментировать*/
//            fatalError("Star/End of substring")
//            return substringRange(in: position - 1)
        }
        let nsRange = NSRange(position...position)
        let paragraphRange = (self as NSString).paragraphRange(for: nsRange)
        let swiftRange = ClosedRange(uncheckedBounds: (paragraphRange.lowerBound, paragraphRange.upperBound - (self.count != paragraphRange.upperBound ? 2 : 1)))
        return swiftRange
    }
}

print(str.substringRange(in: 5))
print(str2.substringRange(in: 5))
